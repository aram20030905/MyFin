//

//  AirbnbTutorial.swift

// AirbnbTutorial

//

//  Created by user on 12/23/24.

//



import SwiftUI



@main

struct AirbnbTutorial: App {

    var body: some Scene {

        WindowGroup {

            ContentView()

        }

    }

}



